//Declare all global variables
var ground, monkeyHand, reset,
monkey, monkeyAutomatedCollider, gameState,
monkeyAutomatedColliderMonkeyXAddNumber,
waitageTime, score, time, PLAY, END, stones, bananas,
singlePlayerButton, automatedPlayingButton;

function preload()
{
  
}

function setup()
{
  createCanvas(400, 400);
  
  //Do the setup for the already defined variables
  doSetup();
}

function controlGameWithGameStates()
{
  //When the game is not yet started
  if(gameState === "notStarted")
  {
    waitageTime += 1;
    ground.velocityX = 0;
    // Print all the texts
    textSize(15);
    text('Press these buttons to start playing, control the monkey with'
    +' the arrow keys and spacebar if you are not in '
    +'automated gaimng mode.'
    +' Else, if you are, enjoy watching!', 5, 290, 395);
    textSize(18);
    fill("black");
    text("Play with", 85, 195, 180, 235);
    text("Controlling", 85, 220, 180, 235);
    textSize(13);
    text("Enter Automated ", 222.5, 205, 200);
    text("Gaming mode", 222.5, 230, 200);
    textSize(15);
    //Set some properties for the objects when game is not started
    monkey.visible = false;
    monkeyHand.visible = false;
    singlePlayerButton.visible = true;
    automatedPlayingButton.visible = true;
    reset.visible = false;
    score = 0;
    time = 0;
    //Check which button is pressed to start the game
    if(mousePressedOver(singlePlayerButton))
    {
      gameState = PLAY[0];
    }
    
    if(mousePressedOver(automatedPlayingButton))
    {
      gameState = PLAY[1];
    }

  }
  
  //Do something when the game state is not equal to not started
  if(gameState != "notStarted")
  {
    //Write some texts when the game state is not equal to not started
    textSize(20);
    fill("black");
    text("Survival Time: " + time, 100, 50);
    text("Score: " + score, 100, 120);
 }
  
  //When the player wants to control the game himself
  if(gameState === PLAY[0])
  {
    //Set some properties
    time += Math.round((World.frameRate/30));
    monkey.visible = true;
    monkeyHand.visible = true;
    singlePlayerButton.visible = false;
    automatedPlayingButton.visible = false;
    // Spawn the objects
    spawnStones();
    spawnBananas();
    
    if(ground.velocityX === 0)
    {
      monkey.setAnimation("monkey_jump");
    }
    if(keyDown("space") || keyDown("up"))
    {
      if(monkey.y > 320)
      {
        monkey.velocityY -= 11.3;
      }
    }
    else
    {
      monkey.setAnimation("monkey");
    }
    
    if(monkey.isTouching(stones))
    {
      gameState = END;
    }
    
    if(monkey.y < 320 || ground.velocityX === 0)
    {
      monkey.setAnimation("monkey_jump");
      monkeyHand.visible = true;
      monkeyHand.rotationSpeed = 16;
    }else
    {
      monkey.setAnimation("monkey");
      monkeyHand.visible = false;
    }
    if(keyWentDown("space") || keyWentDown("up"))
    {
      monkeyHand.pointTo(190, 390);
    }
    
    if(ground.velocityX === 0)
    {
      bananas.setVelocityYEach(0);
    }
    
    if(monkey.isTouching(bananas) || monkeyHand.isTouching(bananas))
    {
      bananas.destroyEach();
      score += 5;
    }
    
  }
  
  // Perform some actions when the player is just seeing the game
  if(gameState === PLAY[1])
  {
    // Automated gaming mode has been entered
    monkey.visible = true;
    monkeyHand.visible = true;
    singlePlayerButton.visible = false;
    automatedPlayingButton.visible = false;
    
    // Spawn the objects
    spawnStones();
    spawnBananas();
    time += Math.round((World.frameRate/30));
    
    // Check for the conditions and perform the actions
    if(ground.velocityX === 0)
    {
      monkey.setAnimation("monkey_jump");
    }
    if(monkey.y < 320){
      monkey.setAnimation("monkey");
    }
    
    if(monkey.isTouching(stones))
    {
      gameState = END;
    }
    
    if(monkey.isTouching(bananas) || monkeyHand.isTouching(bananas))
    {
      bananas.destroyEach();
      score += 5;
    }
        
    if(monkeyAutomatedCollider.isTouching(stones) &&  monkey.y > 320)
    {
      monkey.velocityY = -11.3;
    }

    if(monkeyAutomatedCollider.isTouching(bananas) && monkey.y > 320)
    {
      monkey.velocityY = -11.3;
    }

    if(monkey.y < 320 || ground.velocityX === 0)
    {
      monkey.setAnimation("monkey_jump");
      monkeyHand.visible = true;
      monkeyHand.rotationSpeed = 16;
    }
    else
    {
      monkey.setAnimation("monkey");
      monkeyHand.visible = false;
    }
   
  }
  
  // When the game has been ended, perform the following actions
  if(gameState === END)
  {
    //Player lost!
    monkey.setAnimation("monkey_jump");
    monkey.rotation = -120;
    monkey.y += 0.4;
    monkeyHand.visible = true;
    monkeyHand.rotationSpeed = 0;
    ground.velocityX = 0;
    stones.setVelocityXEach(-14);
    bananas.setVelocityXEach(-8);
    text("Game Over! Don't you want to play again?"+
    "                                  :D", 15, 195, 385);
    reset.visible = true;
    reset.setAnimation("reset");
    if(mousePressedOver(reset))
    {
      gameState = "notStarted";
      monkey.rotation = 0;
    }
  }
}

  }
}
function spawnStones()
{
  if(World.frameCount % 180 === 0)
  {
    //Spawn the stones when the condition is true
    var stone = createSprite(500, 200);
    stone.setAnimation("stone");
    stone.scale = 0.1;
    stone.setCollider("circle", 0, 0, 105);
    stone.rotationSpeed = ground.velocityX * 5 / 3;
    stone.velocityY += 10;
    stones.add(stone);
    monkeyAutomatedColliderMonkeyXAddNumber = randomNumber(70, 90);
  }
}
function setPropertiesOfObjects()
{
  // Set the properties of the objects
  stones.setVelocityXEach((ground.velocityX * 5) / 8);
  bananas.setVelocityXEach((ground.velocityX * 5) / 8);
  monkeyHand.setCollider("rectangle", 0, 0, 20, 25, monkeyHand.rotation);
  monkey.collide(ground);
  monkeyHand.x = monkey.x + 10;
  monkeyHand.y = monkey.y - 5;
  monkeyAutomatedCollider.x = monkey.x 
  + monkeyAutomatedColliderMonkeyXAddNumber;
  monkeyAutomatedCollider.y = monkey.y;
  if(ground.velocityX <= 0 && ground.velocityX > -23)
  {
    ground.velocityX = -1 * ((3 + 2 * time / 50));
  }
  stones.collide(ground);
  bananas.collide(ground);
  monkey.velocityY += 0.8;
  if(ground.x < 100)
  {
    ground.x = 300;
  }

}
function keyPressed() {
    if (keyCode === DOWN_ARROW) {
        Matter.Body.setStatic(pack, false);
    }
}

function print(logs) {
    console.log(logs);
}

function displayImagesObjectsAndTexts() {
    pack.position.x = 100;
    groundObj.display();
    copterObj.display();
    packObj.display();

    text("MouseX: " + mouseX, 500, 250);
    text("MouseY: " + mouseY, 500, 450);

    rect(groundObj.leftX, groundObj.topY, 800, 80);
    rect(copter.position.x, copter.position.y, copterObj.width, copterObj.height);
    ellipse(pack.position.x, pack.position.y, packObj.radius);

    packObj.displayImage(packImage, packImageX, packImageY, 0.6, null, null);

    copterObj.displayImage(helicopterImage, helicopterImageX, helicopterImageY, 2, null, null);
}

function setProperties() {

    copter.position.x += 7;

    copterObj.centerX = copter.position.x;
    copterObj.centerY = copter.position.y;

    packObj.centerX = pack.position.x;
    packObj.centerY = pack.position.y;

    helicopterImageX = copterObj.centerX - (helicopterImage.width / 2);
    helicopterImageY = copterObj.centerY - (helicopterImage.height / 2);

    if (pack.position.y < 210) {
        packImageX = copterObj.centerX - (packImage.width / 2);
    }

    packImageY = packObj.centerY - (packImage.height / 2);

    if (pack.position.y > 210) {
        packImageX -= 7;
    }
}
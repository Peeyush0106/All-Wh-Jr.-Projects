function preload() {
    helicopterImage = loadImage(CopterImagePath);
    packImage = loadImage(PackageImagePath);
}

function setup() {
    createCanvas(800, 700);

    engine = Engine.create();

    world = engine.world;

    pack_options = {
        restitution: 4, isStatic: true
    }

    ground_options = {
        isStatic: true
    }

    copter_options = {
        isStatic: true
    }

    // In the following three objects the center X and center Y is being used.
    copter = Bodies.rectangle(-300, 200, 100, 70, copter_options);

    pack = Bodies.circle(400, 200, 70, pack_options);

    ground = Bodies.rectangle(400, 675, 800, 50, ground_options);

    groundObj = new Shape(ground.position.x, ground.position.y, 800, 80, null, "white", false);

    packObj = new Shape(pack.position.x, pack.position.y, null, null, 50, "white", false);

    copterObj = new Shape(copter.position.x, copter.position.y, 100, 70, null, "white", false);

    packImage.width = 80;
    packImage.height = 80;

    Engine.run(engine);

    World.add(world, ground);
    // World.add(world, groundObj);
    World.add(world, pack);
    World.add(world, copter);
}